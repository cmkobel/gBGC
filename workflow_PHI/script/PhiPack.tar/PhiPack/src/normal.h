#ifndef NORM
#define NORMAL
double normal_01_cdf ( double x );

#endif
